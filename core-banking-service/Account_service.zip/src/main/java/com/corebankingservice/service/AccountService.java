package com.corebankingservice.service;

import com.corebankingservice.repository.AccountRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AccountService {

    private final AccountRepository accountRepository;

    @Transactional(readOnly=true)
    public boolean checkBalance(String account_number){

        return accountRepository.findByAccountNumber().isPresent();

    }
}
