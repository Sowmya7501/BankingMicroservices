package com.corebankingservice.controller;

import com.corebankingservice.service.AccountService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/account")
@RequiredArgsConstructor
public class AccountController {

    private final AccountService accountService;

    @GetMapping("/{account-number}")
    @ResponseStatus(HttpStatus.OK)
    public boolean checkBalance(@PathVariable("account-number") String account_number){
        return accountService.checkBalance(account_number);
    }
}
