package com.transactionservice.service;

import com.transactionservice.dto.TransactionRequest;
import com.transactionservice.model.Transaction;
import com.transactionservice.repository.TransactionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.UUID;


@Service
@RequiredArgsConstructor
public class TransactionService {

    private final TransactionRepository transactionRepository;

    public void completeTransaction(TransactionRequest transactionRequest){
        Transaction transaction = new Transaction();
        System.out.println(transactionRequest.getAmount());
        System.out.println(transactionRequest.getReceiver_account());
        System.out.println(transactionRequest.getSender_account());
        transaction.setTransaction_number(UUID.randomUUID().toString());
        transaction.setSender_account(transactionRequest.getSender_account());
        transaction.setReceiver_account(transactionRequest.getReceiver_account());
        transaction.setAmount(transactionRequest.getAmount());

        transactionRepository.save(transaction);
    }
}
